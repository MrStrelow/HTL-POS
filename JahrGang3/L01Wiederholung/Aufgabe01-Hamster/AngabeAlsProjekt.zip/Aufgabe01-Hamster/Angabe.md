## Hamster verfollständigen
Öffne das im Zip-File angegebene ``Projekt`` (oder arbeite bei deinem eigenen weiter) in einer ``Solution`` (deine Mitschrift).
1. Behebe alle TODOs in den angegebenen Klassen.
2. Erstelle das Klassendiagramm (ClassDiagramm.cd) nachdem du im Visual studio Installer die entsprechende extension installiert hast (siehe google/AI).